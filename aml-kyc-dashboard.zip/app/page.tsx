import { AMLDashboard } from "@/components/aml-dashboard"

export default function Home() {
  return <AMLDashboard />
}
